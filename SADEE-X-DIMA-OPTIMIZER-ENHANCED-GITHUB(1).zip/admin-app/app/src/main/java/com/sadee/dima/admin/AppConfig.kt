package com.sadee.dima.admin
object AppConfig {
    const val SUPABASE_URL = "https://YOUR_PROJECT.supabase.co"
    const val SUPABASE_ANON_KEY = "YOUR_ANON_KEY"
    const val ADMIN_FUNCTION = "$SUPABASE_URL/functions/v1/admin-key"
}
