create extension if not exists pgcrypto;

create table if not exists public.license_keys (
  id uuid primary key default gen_random_uuid(),
  key text unique not null,
  plan text not null check (plan in ('1','3','5','7','14','30','lifetime')),
  duration_days integer,
  created_at timestamptz not null default now(),
  expires_at timestamptz,
  status text not null default 'active' check (status in ('active','revoked','expired')),
  bound_device_id text,
  bound_device_name text,
  bound_user_id uuid,
  last_seen_at timestamptz,
  notes text
);
create index if not exists license_keys_key_idx on public.license_keys(key);
create index if not exists license_keys_device_idx on public.license_keys(bound_device_id);
alter table public.license_keys enable row level security;
revoke all on public.license_keys from anon, authenticated;

create table if not exists public.app_config (
  id boolean primary key default true,
  latest_version_code integer not null default 1,
  latest_version_name text not null default '1.0',
  apk_url text,
  update_message text not null default '',
  force_update boolean not null default false,
  updated_at timestamptz not null default now()
);
insert into public.app_config(id) values(true) on conflict(id) do nothing;
alter table public.app_config enable row level security;
revoke all on public.app_config from anon, authenticated;

create table if not exists public.admin_audit (
  id bigint generated always as identity primary key,
  admin_email text not null,
  action text not null,
  license_id uuid,
  metadata jsonb,
  created_at timestamptz not null default now()
);
alter table public.admin_audit enable row level security;
revoke all on public.admin_audit from anon, authenticated;

create or replace function public.generate_license_key(prefix text default 'SD')
returns text language plpgsql as $$
begin
  return upper(prefix)||'-'||encode(gen_random_bytes(4),'hex')||'-'||encode(gen_random_bytes(4),'hex')||'-'||encode(gen_random_bytes(4),'hex');
end; $$;
