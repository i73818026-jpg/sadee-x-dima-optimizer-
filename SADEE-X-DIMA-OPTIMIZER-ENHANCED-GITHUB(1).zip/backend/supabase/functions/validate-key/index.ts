import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...cors, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });

  try {
    const { key, deviceId, deviceName } = await req.json();
    if (!key || !deviceId) return json({ ok: false, error: "Missing key/deviceId" }, 400);

    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data, error } = await admin
      .from("license_keys")
      .select("*")
      .eq("key", String(key).trim().toUpperCase())
      .maybeSingle();

    if (error || !data) return json({ ok: false, error: "Invalid key" }, 401);

    if (data.status === "revoked") return json({ ok: false, error: "Key revoked" }, 403);

    if (data.expires_at && new Date(data.expires_at).getTime() <= Date.now()) {
      await admin.from("license_keys").update({ status: "expired" }).eq("id", data.id);
      return json({ ok: false, error: "Key expired" }, 403);
    }

    // First activation binds the key. Later activations must come from the same device.
    if (data.bound_device_id && data.bound_device_id !== deviceId) {
      return json({ ok: false, error: "Key is already bound to another device" }, 403);
    }

    const update = {
      bound_device_id: data.bound_device_id ?? deviceId,
      bound_device_name: deviceName ?? data.bound_device_name,
      last_seen_at: new Date().toISOString(),
    };

    const { error: updateError } = await admin
      .from("license_keys")
      .update(update)
      .eq("id", data.id);

    if (updateError) return json({ ok: false, error: "Could not bind key" }, 500);

    return json({
      ok: true,
      plan: data.plan,
      expiresAt: data.expires_at,
      deviceName: update.bound_device_name,
    });
  } catch (e) {
    return json({ ok: false, error: String(e) }, 500);
  }
});
