const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type"};
Deno.serve(async(req)=>{
 if(req.method==="OPTIONS") return new Response("ok",{headers:cors});
 const {createClient}=await import("https://esm.sh/@supabase/supabase-js@2");
 const admin=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
 const {data,error}=await admin.from("app_config").select("latest_version_code,latest_version_name,apk_url,update_message,force_update,updated_at").eq("id",true).single();
 if(error)return new Response(JSON.stringify({error:error.message}),{status:500,headers:{...cors,"Content-Type":"application/json"}});
 return new Response(JSON.stringify(data),{headers:{...cors,"Content-Type":"application/json"}});
});
