import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...cors, "Content-Type": "application/json" },
  });
}

function makeKey() {
  const part = () => crypto.randomUUID().replaceAll("-", "").slice(0, 8).toUpperCase();
  return `SD-${part()}-${part()}-${part()}`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });

  const auth = req.headers.get("Authorization");
  if (!auth) return json({ error: "Missing authorization" }, 401);

  const userClient = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: auth } } }
  );
  const { data: { user } } = await userClient.auth.getUser();
  if (!user) return json({ error: "Unauthorized" }, 401);

  // Replace this with a proper profiles/roles table for production.
  const allowed = (Deno.env.get("ADMIN_EMAILS") ?? "")
    .split(",").map(x => x.trim().toLowerCase()).filter(Boolean);
  if (!allowed.includes((user.email ?? "").toLowerCase())) {
    return json({ error: "Admin access denied" }, 403);
  }

  const admin = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {
    const body = await req.json();
    const audit = async (action: string, licenseId: string | null, metadata: unknown = {}) => {
      await admin.from("admin_audit").insert({ admin_email: user.email ?? "", action, license_id: licenseId, metadata });
    };
    const action = body.action;

    if (action === "list") {
      const { data, error } = await admin.from("license_keys").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return json({ items: data ?? [] });
    }

    if (action === "generate") {
      const plan = String(body.plan);
      const allowedPlans = ["1","3","5","7","14","30","lifetime"];
      if (!allowedPlans.includes(plan)) return json({ error: "Invalid plan" }, 400);

      const key = makeKey();
      let expires_at: string | null = null;
      if (plan !== "lifetime") {
        const d = new Date();
        d.setUTCDate(d.getUTCDate() + Number(plan));
        expires_at = d.toISOString();
      }

      const { data, error } = await admin.from("license_keys").insert({
        key, plan, duration_days: plan === "lifetime" ? null : Number(plan), expires_at
      }).select().single();
      if (error) throw error;
      await audit("generate", data.id, { plan });
      return json({ item: data });
    }

    if (action === "revoke" || action === "delete") {
      const id = String(body.id);
      const patch = action === "revoke" ? { status: "revoked" } : null;
      const query = admin.from("license_keys").delete().eq("id", id);
      if (patch) {
        const { data, error } = await admin.from("license_keys").update(patch).eq("id", id).select().single();
        if (error) throw error;
        await audit("revoke", id);
        return json({ item: data });
      }
      const { error } = await query;
      if (error) throw error;
      await audit("delete", id);
      return json({ ok: true });
    }

    if (action === "update_config") {
      const patch = {
        latest_version_code: Number(body.latest_version_code ?? 1),
        latest_version_name: String(body.latest_version_name ?? "1.0"),
        apk_url: body.apk_url ? String(body.apk_url) : null,
        update_message: String(body.update_message ?? ""),
        force_update: Boolean(body.force_update),
        updated_at: new Date().toISOString(),
      };
      const { data, error } = await admin.from("app_config").update(patch).eq("id", true).select().single();
      if (error) throw error;
      return json({ item: data });
    }

    if (action === "get_config") {
      const { data, error } = await admin.from("app_config").select("*").eq("id", true).single();
      if (error) throw error;
      return json({ item: data });
    }

    if (action === "extend") {
      const id = String(body.id);
      const days = Number(body.days);
      if (!Number.isFinite(days) || days <= 0) return json({ error: "Invalid days" }, 400);
      const { data: current, error: readError } = await admin.from("license_keys").select("*").eq("id", id).single();
      if (readError) throw readError;
      if (!current.expires_at) return json({ error: "Lifetime key cannot be extended" }, 400);
      const base = Math.max(Date.now(), new Date(current.expires_at).getTime());
      const expires_at = new Date(base + days * 86400000).toISOString();
      const { data, error } = await admin.from("license_keys").update({
        expires_at, status: "active"
      }).eq("id", id).select().single();
      if (error) throw error;
      await audit("extend", id, { days });
      return json({ item: data });
    }

    return json({ error: "Unknown action" }, 400);
  } catch (e) {
    return json({ error: String(e) }, 500);
  }
});
