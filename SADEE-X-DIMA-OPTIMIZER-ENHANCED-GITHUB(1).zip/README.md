# 𝕤𝕒𝕕𝕖𝕖 𝕏 𝕕𝕚𝕞𝕒 𝕠𝕡𝕥𝕚𝕞𝕚𝕫𝕖𝕣 — Enhanced GitHub Build

This version expands the optimizer UI into a multi-section Android utility while keeping device-level actions honest and API-based.

## Optimizer app features

- Live dashboard and health score
- Real RAM total/free telemetry
- Real storage total/free telemetry
- Battery level + charging state
- Thermal status
- Network transport status
- CPU model, screen metrics and uptime
- Five-second auto refresh
- Turbo page with Android-safe refresh/settings actions
- RAM refresh request (does not falsely claim to free other apps' RAM)
- Own-app cache cleanup
- Android storage manager shortcut
- Installed-app scanner
- System-app filtering
- Gaming Center with game discovery and launch
- Free Fire / Free Fire MAX launcher
- Gaming preparation action
- Display, Wi-Fi, Bluetooth and Android Settings shortcuts
- License activation with live expiry countdown
- SADEE X DIMA branding/logo

## Important Android limitations

A normal non-root Android application cannot silently overclock the CPU/GPU, force-stop arbitrary third-party apps, or erase another app's private data. The app therefore uses public Android APIs and system settings instead of fake optimization claims.

The installed-app scanner uses QUERY_ALL_PACKAGES. If this app is distributed through Google Play, review Google's package-visibility policy and declare the permission only when the use case qualifies.

## Build

Push the repository to GitHub. The included GitHub Actions workflow builds both the optimizer and admin APKs.

For the license backend, configure the Supabase values described in the original backend README before expecting real online key validation.
