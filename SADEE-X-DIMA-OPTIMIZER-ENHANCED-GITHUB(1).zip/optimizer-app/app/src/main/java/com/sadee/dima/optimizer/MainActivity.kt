package com.sadee.dima.optimizer

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.os.StatFs
import android.provider.Settings
import android.text.format.Formatter
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.util.UUID
import kotlin.concurrent.thread
import kotlin.math.roundToInt

private data class DeviceStats(
    val model: String,
    val android: String,
    val ramTotal: Long,
    val ramAvail: Long,
    val storageTotal: Long,
    val storageFree: Long,
    val battery: Int,
    val charging: Boolean,
    val thermal: String,
    val network: String,
    val cpu: String,
    val screen: String,
    val uptime: String
)
private data class InstalledApp(val label: String, val packageName: String, val system: Boolean)

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("license", MODE_PRIVATE) }
    private var licenseTimer: Thread? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OptimizerApp() }
    }

    override fun onDestroy() { licenseTimer?.interrupt(); super.onDestroy() }

    private fun deviceId(): String = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
        ?: UUID.randomUUID().toString()

    private fun stats(): DeviceStats {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val s = StatFs(filesDir.absolutePath)
        val batteryIntent = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val thermal = if (Build.VERSION.SDK_INT >= 29) {
            when ((getSystemService(POWER_SERVICE) as PowerManager).currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "Normal"
                PowerManager.THERMAL_STATUS_LIGHT -> "Light"
                PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
                PowerManager.THERMAL_STATUS_SEVERE -> "Severe"
                PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
                PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown"
                else -> "Unknown"
            }
        } else "Not available"
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.activeNetwork?.let { cm.getNetworkCapabilities(it) }
        val network = when {
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi‑Fi"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "Mobile data"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "Ethernet"
            else -> "Offline"
        }
        val dm = resources.displayMetrics
        val screen = "${(dm.widthPixels / dm.density).roundToInt()}×${(dm.heightPixels / dm.density).roundToInt()} • ${dm.densityDpi} dpi"
        val uptime = android.os.SystemClock.elapsedRealtime() / 1000
        val h = uptime / 3600
        val m = (uptime / 60) % 60
        return DeviceStats(
            "${Build.MANUFACTURER} ${Build.MODEL}",
            "Android ${Build.VERSION.RELEASE} • API ${Build.VERSION.SDK_INT}",
            mi.totalMem, mi.availMem, s.totalBytes, s.availableBytes,
            if (scale > 0) (level * 100 / scale) else 0, charging, thermal, network,
            readCpuModel(), screen, "%02dh %02dm".format(h, m)
        )
    }

    private fun readCpuModel(): String {
        return runCatching {
            File("/proc/cpuinfo").useLines { lines ->
                lines.firstOrNull { it.startsWith("model name") || it.startsWith("Hardware") || it.startsWith("Processor") }
                    ?.substringAfter(':')?.trim()
            }
        }.getOrNull() ?: "CPU information unavailable"
    }

    private fun postJson(url: String, body: JSONObject, bearer: String? = null): JSONObject {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 12000; readTimeout = 12000; doOutput = true
            setRequestProperty("Content-Type", "application/json")
            if (AppConfig.SUPABASE_ANON_KEY.isNotBlank()) setRequestProperty("apikey", AppConfig.SUPABASE_ANON_KEY)
            if (!bearer.isNullOrBlank()) setRequestProperty("Authorization", "Bearer $bearer")
        }
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val text = (if (c.responseCode in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        return JSONObject(text)
    }

    private fun validateKey(key: String, callback: (Boolean, String, String?) -> Unit) {
        thread {
            try {
                val r = postJson(AppConfig.VALIDATE_FUNCTION, JSONObject()
                    .put("key", key).put("deviceId", deviceId()).put("deviceName", stats().model))
                val ok = r.optBoolean("ok", false)
                val expiry = r.optString("expiresAt", null)
                if (ok) prefs.edit().putString("key", key).putString("expiresAt", expiry).apply()
                runOnUiThread { callback(ok, r.optString("error", "Activated"), expiry) }
            } catch (e: Exception) {
                runOnUiThread { callback(false, "Network error: ${e.message}", null) }
            }
        }
    }

    private fun cacheSize(f: File?): Long = if (f == null || !f.exists()) 0 else if (f.isFile) f.length() else f.listFiles()?.sumOf(::cacheSize) ?: 0
    private fun clearOwnCache(): Long {
        val before = cacheSize(cacheDir) + cacheSize(externalCacheDir)
        cacheDir.deleteRecursively(); externalCacheDir?.deleteRecursively()
        return before
    }

    private fun openSystem(action: String, fallback: String = Settings.ACTION_SETTINGS) {
        try { startActivity(Intent(action)) } catch (_: Exception) { startActivity(Intent(fallback)) }
    }

    private fun launchPackage(pkg: String): Boolean {
        val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return false
        startActivity(intent); return true
    }

    private fun installedApps(): List<InstalledApp> = packageManager.getInstalledApplications(0)
        .filter { it.packageName != packageName }
        .map { InstalledApp(packageManager.getApplicationLabel(it).toString(), it.packageName, (it.flags and ApplicationInfo.FLAG_SYSTEM) != 0) }
        .distinctBy { it.packageName }.sortedBy { it.label.lowercase() }

    private fun healthScore(s: DeviceStats): Int {
        val ram = ((s.ramAvail.toDouble() / s.ramTotal) * 100).coerceIn(0.0, 100.0)
        val storage = ((s.storageFree.toDouble() / s.storageTotal) * 100).coerceIn(0.0, 100.0)
        val thermal = when (s.thermal) { "Normal" -> 100; "Light" -> 90; "Moderate" -> 70; "Severe" -> 40; else -> 20 }
        return ((ram * .35) + (storage * .25) + (s.battery * .20) + (thermal * .20)).roundToInt()
    }

    @Composable
    fun OptimizerApp() {
        var s by remember { mutableStateOf(stats()) }
        var apps by remember { mutableStateOf(emptyList<InstalledApp>()) }
        var scanning by remember { mutableStateOf(false) }
        var selectedGame by remember { mutableStateOf<InstalledApp?>(null) }
        var message by remember { mutableStateOf("Monitoring active") }
        var page by remember { mutableIntStateOf(0) }
        var key by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
        var expiry by remember { mutableStateOf(prefs.getString("expiresAt", "") ?: "") }
        var activated by remember { mutableStateOf(key.isNotBlank() && (expiry.isBlank() || runCatching { Instant.parse(expiry).toEpochMilli() > System.currentTimeMillis() }.getOrDefault(false))) }
        var countdown by remember { mutableStateOf("") }
        var autoRefresh by remember { mutableStateOf(true) }
        var showSystemApps by remember { mutableStateOf(false) }

        LaunchedEffect(autoRefresh) {
            while (autoRefresh) { delay(5000); s = stats() }
        }
        LaunchedEffect(expiry, activated) {
            while (true) {
                countdown = if (expiry.isBlank()) "LIFETIME" else runCatching {
                    val ms = Instant.parse(expiry).toEpochMilli() - System.currentTimeMillis()
                    if (ms <= 0) { activated = false; "EXPIRED" } else {
                        val d = ms / 86400000; val h = (ms / 3600000) % 24; val m = (ms / 60000) % 60; val sec = (ms / 1000) % 60
                        "%02dd %02dh %02dm %02ds".format(d, h, m, sec)
                    }
                }.getOrDefault("--")
                delay(1000)
            }
        }
        LaunchedEffect(key, activated) {
            while (activated && key.isNotBlank()) {
                validateKey(key) { ok, msg, ex -> activated = ok; if (ex != null) expiry = ex; if (!ok) message = msg }
                delay(60000)
            }
        }

        MaterialTheme(colorScheme = darkColorScheme(
            primary = Color(0xFF00E5A0), secondary = Color(0xFF55B8FF), background = Color(0xFF05070A), surface = Color(0xFF0D1218)
        )) {
            Scaffold(
                topBar = { Header(s, activated, countdown) },
                bottomBar = {
                    NavigationBar(containerColor = Color(0xFF080B10)) {
                        navItem("⌂", "Home", page == 0) { page = 0 }
                        navItem("⚡", "Turbo", page == 1) { page = 1 }
                        navItem("🎮", "Gaming", page == 2) { page = 2 }
                        navItem("🧹", "Clean", page == 3) { page = 3 }
                        navItem("⋮", "More", page == 4) { page = 4 }
                        navItem("🔥", "Free Fire", page == 5) { page = 5 }
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad).fillMaxSize()) {
                    when (page) {
                        0 -> HomePage(s, healthScore(s), message, autoRefresh, { autoRefresh = it }, { s = stats(); message = "Optimization scan refreshed" }, activated)
                        1 -> TurboPage(s, activated, message, { s = stats(); message = "Device health refreshed" }, { openSystem(Settings.ACTION_BATTERY_SAVER_SETTINGS) }, { openSystem(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Settings.ACTION_SETTINGS); message = "App settings opened" }, { System.gc(); s = stats(); message = "RAM refresh requested — Android manages other apps" }, { val n = clearOwnCache(); s = stats(); message = "Cleaned ${fmt(n)} of this app's cache" })
                        2 -> GamingPage(s, apps, selectedGame, scanning, activated, { selectedGame = it }, { scanning = true; thread { val list = installedApps().filter { it.label.contains("game", true) || it.packageName.contains("game", true) || it.packageName.contains("garena", true) || it.packageName.contains("pubg", true) || it.packageName.contains("mobile.legends", true) }; runOnUiThread { apps = list; scanning = false; message = "${list.size} games detected" } } }, { selectedGame?.let { if (launchPackage(it.packageName)) message = "Launched ${it.label}" } }, { System.gc(); s = stats(); message = "Gaming preparation complete" })
                        3 -> CleanPage(apps, scanning, showSystemApps, { showSystemApps = it }, { scanning = true; thread { val list = installedApps(); runOnUiThread { apps = list; scanning = false; message = "${list.size} installed apps scanned" } } }, { val n = clearOwnCache(); s = stats(); message = "Cleaned ${fmt(n)} of this app's cache" }, { openSystem(Settings.ACTION_MANAGE_STORAGE, Settings.ACTION_SETTINGS) }, { openSystem(Settings.ACTION_INTERNAL_STORAGE_SETTINGS, Settings.ACTION_SETTINGS) })
                        4 -> MorePage(s, key, activated, countdown, message, { key = it }, { if (key.isBlank()) message = "KEY REQUIRED" else { message = "Verifying license…"; validateKey(key) { ok, msg, ex -> activated = ok; if (ex != null) expiry = ex; message = if (ok) "License activated" else msg } } }, { openSystem(Settings.ACTION_DISPLAY_SETTINGS) }, { openSystem(Settings.ACTION_WIFI_SETTINGS) }, { openSystem(Settings.ACTION_BLUETOOTH_SETTINGS) }, { openSystem(Settings.ACTION_SETTINGS) })
                        5 -> FreeFirePage(s, activated, { if (launchPackage("com.dts.freefireth")) message = "Free Fire launched" else if (launchPackage("com.dts.freefiremax")) message = "Free Fire MAX launched" else message = "Free Fire / MAX is not installed" }, { System.gc(); s = stats(); message = "Free Fire launch optimization prepared" })
                    }
                }
            }
        }
    }

    @Composable private fun Header(s: DeviceStats, active: Boolean, countdown: String) {
        Card(Modifier.fillMaxWidth().padding(10.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1016))) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(com.sadee.dima.optimizer.R.drawable.sadee_dima_logo), contentDescription = "SADEE X DIMA", Modifier.size(58.dp))
                Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) {
                    Text("𝕤𝕒𝕕𝕖𝕖 𝕏 𝕕𝕚𝕞𝕒 𝕠𝕡𝕥𝕚𝕞𝕚𝕫𝕖𝕣", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text("● REAL ANDROID MONITOR", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
                }
                Column(horizontalAlignment = Alignment.End) { Text("${s.battery}%", fontWeight = FontWeight.Bold); Text(if (active) countdown else "LOCKED", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary) }
            }
        }
    }

    @Composable private fun HomePage(s: DeviceStats, score: Int, message: String, auto: Boolean, setAuto: (Boolean) -> Unit, refresh: () -> Unit, active: Boolean) {
        PageScroll {
            Title("Live Dashboard", "Monitor your phone before you launch a game")
            Card { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("REAL PERFORMANCE HEALTH", style = MaterialTheme.typography.labelLarge)
                Text(score.toString(), fontSize = 56.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                Text("Health score from RAM, storage, battery and thermal state. It is not a benchmark.")
                Button(onClick = refresh, modifier = Modifier.fillMaxWidth(), enabled = active) { Text("⚡ REFRESH / OPTIMIZE SCAN") }
            }}
            StatGrid(s)
            Card { Column(Modifier.padding(16.dp)) { Text("LIVE STATUS", fontWeight = FontWeight.Bold); Text(message, color = MaterialTheme.colorScheme.primary); Text("RAM, storage, battery, network and thermal values come from Android APIs.") } }
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Auto refresh (5 sec)", Modifier.weight(1f)); Switch(auto, setAuto) }
            QuickSettings()
        }
    }

    @Composable private fun TurboPage(s: DeviceStats, active: Boolean, message: String, refresh: () -> Unit, battery: () -> Unit, appSettings: () -> Unit, ram: () -> Unit, cache: () -> Unit) {
        PageScroll { Title("Turbo", "Real safe actions — no fake RAM boost or overclock")
            Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("⚡ DEVICE OPTIMIZATION", color = MaterialTheme.colorScheme.primary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Android does not allow a normal app to overclock CPU/GPU or force-stop other apps. These controls use public system APIs.")
                ActionButton("REFRESH DEVICE HEALTH", refresh, active); ActionButton("OPEN BATTERY SETTINGS", battery, true); ActionButton("OPEN APP SETTINGS", appSettings, true); ActionButton("⚡ RAM BOOST / REFRESH", ram, active); ActionButton("🧹 CLEAR THIS APP CACHE", cache, active)
            }}
            HealthList(s); Text("STATUS: $message", color = MaterialTheme.colorScheme.primary)
        }
    }

    @Composable private fun GamingPage(s: DeviceStats, apps: List<InstalledApp>, selected: InstalledApp?, scanning: Boolean, active: Boolean, select: (InstalledApp) -> Unit, scan: () -> Unit, launch: () -> Unit, prepare: () -> Unit) {
        PageScroll { Title("Gaming Center", "Prepare your device, choose a game and launch it")
            StatGrid(s)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { ActionButton("🔎 SCAN GAMES", scan, active, Modifier.weight(1f)); ActionButton("⚡ PREPARE", prepare, active, Modifier.weight(1f)) }
            if (selected != null) Card { Column(Modifier.padding(16.dp)) { Text("SELECTED GAME", fontWeight = FontWeight.Bold); Text(selected.label, fontSize = 20.sp); Text(selected.packageName); ActionButton("🚀 LAUNCH GAME", launch, active) } }
            Text(if (scanning) "Scanning games…" else "Detected / scanned games", style = MaterialTheme.typography.titleMedium)
            itemsColumn(apps) { a -> ListItem(headlineContent = { Text(a.label) }, supportingContent = { Text(a.packageName) }, trailingContent = { TextButton({ select(a) }) { Text("SELECT") } }) }
        }
    }

    @Composable private fun CleanPage(apps: List<InstalledApp>, scanning: Boolean, showSystem: Boolean, setShowSystem: (Boolean) -> Unit, scan: () -> Unit, cache: () -> Unit, storage: () -> Unit, internal: () -> Unit) {
        PageScroll { Title("Smart Clean", "Scan installed apps and use Android's real storage controls")
            Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("🧹 CLEAN CENTER", color = MaterialTheme.colorScheme.primary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("A normal app can safely clean its own cache. System-wide cache/data cleanup is controlled by Android settings.")
                ActionButton("SCAN ALL INSTALLED APPS", scan, true); ActionButton("CLEAR THIS APP CACHE", cache, true); ActionButton("OPEN ANDROID STORAGE MANAGER", storage, true); ActionButton("OPEN INTERNAL STORAGE", internal, true)
            }}
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Show system apps", Modifier.weight(1f)); Switch(showSystem, setShowSystem) }
            Text(if (scanning) "Scanning…" else "${apps.size} apps scanned", style = MaterialTheme.typography.titleMedium)
            itemsColumn(if (showSystem) apps else apps.filterNot { it.system }) { a -> ListItem(headlineContent = { Text(a.label) }, supportingContent = { Text(a.packageName + if (a.system) " • SYSTEM" else "") }) }
        }
    }

    @Composable private fun FreeFirePage(s: DeviceStats, active: Boolean, launch: () -> Unit, prepare: () -> Unit) {
        PageScroll { Title("Optimize @ Launch Free Fire", "Prepare this app, then launch Free Fire automatically")
            Card { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("🔥 FREE FIRE LAUNCH", color = MaterialTheme.colorScheme.primary, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("Uses normal Android app-launching APIs. It does not modify Free Fire files or overclock the phone.")
                InfoRow("Device", s.model); InfoRow("RAM", "${fmt(s.ramAvail)} free / ${fmt(s.ramTotal)} total"); InfoRow("Thermal", s.thermal); InfoRow("Network", s.network)
                ActionButton("⚡ OPTIMIZE @ LAUNCH FREE FIRE", { prepare(); launch() }, active)
            }}
            Card { Column(Modifier.padding(16.dp)) { Text("SUPPORTED", fontWeight = FontWeight.Bold); Text("Free Fire / Free Fire MAX"); Text("If neither package is installed, Android will show no launch action.") } }
        }
    }

    @Composable private fun MorePage(s: DeviceStats, key: String, active: Boolean, countdown: String, message: String, setKey: (String) -> Unit, activate: () -> Unit, display: () -> Unit, wifi: () -> Unit, bluetooth: () -> Unit, settings: () -> Unit) {
        PageScroll { Title("More", "Device tools, license and system shortcuts")
            Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("LICENSE CONTROL", fontWeight = FontWeight.Bold); Text(if (active) "ACTIVE • $countdown" else "LOCKED", color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                OutlinedTextField(key, setKey, label = { Text("License key") }, modifier = Modifier.fillMaxWidth(), singleLine = true); ActionButton("ACTIVATE / REFRESH LICENSE", activate, true); Text(message)
            }}
            Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("DEVICE DETAILS", fontWeight = FontWeight.Bold); InfoRow("Model", s.model); InfoRow("Android", s.android); InfoRow("CPU", s.cpu); InfoRow("Screen", s.screen); InfoRow("Uptime", s.uptime)
            }}
            ActionButton("OPEN DISPLAY SETTINGS", display, true); ActionButton("OPEN WI‑FI SETTINGS", wifi, true); ActionButton("OPEN BLUETOOTH SETTINGS", bluetooth, true); ActionButton("OPEN ANDROID SETTINGS", settings, true)
        }
    }

    @Composable private fun QuickSettings() { Text("QUICK TOOLS", style = MaterialTheme.typography.titleMedium); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { AssistChip(onClick = { openSystem(Settings.ACTION_DISPLAY_SETTINGS) }, label = { Text("Display") }); AssistChip(onClick = { openSystem(Settings.ACTION_WIFI_SETTINGS) }, label = { Text("Wi‑Fi") }); AssistChip(onClick = { openSystem(Settings.ACTION_BATTERY_SAVER_SETTINGS) }, label = { Text("Battery") }) } }

    @Composable private fun StatGrid(s: DeviceStats) { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { StatCard("RAM", "${fmt(s.ramAvail)} free / ${fmt(s.ramTotal)} total", Modifier.weight(1f)); StatCard("STORAGE", "${fmt(s.storageTotal - s.storageFree)} used / ${fmt(s.storageTotal)} total", Modifier.weight(1f)) }; Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { StatCard("BATTERY", "${s.battery}%${if (s.charging) " • charging" else ""}", Modifier.weight(1f)); StatCard("THERMAL", s.thermal, Modifier.weight(1f)) }; Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { StatCard("DEVICE", s.model, Modifier.weight(1f)); StatCard("NETWORK", s.network, Modifier.weight(1f)) } } }

    @Composable private fun HealthList(s: DeviceStats) { Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { InfoRow("🧠 RAM", "${fmt(s.ramAvail)} free / ${fmt(s.ramTotal)} total"); InfoRow("💾 Storage", "${fmt(s.storageTotal - s.storageFree)} used / ${fmt(s.storageTotal)} total"); InfoRow("🔋 Battery", "${s.battery}%${if (s.charging) " • charging" else ""}"); InfoRow("🌡 Thermal", s.thermal); InfoRow("📶 Network", s.network) } } }

    @Composable private fun ActionButton(text: String, onClick: () -> Unit, enabled: Boolean, modifier: Modifier = Modifier) { Button(onClick = onClick, enabled = enabled, modifier = modifier.fillMaxWidth()) { Text(text, fontWeight = FontWeight.Bold) } }
    @Composable private fun Title(title: String, subtitle: String) { Column(Modifier.padding(bottom = 10.dp)) { Text(title, fontSize = 29.sp, fontWeight = FontWeight.Bold); Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
    @Composable private fun InfoRow(label: String, value: String) { Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(label, fontWeight = FontWeight.Bold, modifier = Modifier.weight(.35f)); Text(value, modifier = Modifier.weight(.65f)) } }
    @Composable private fun StatCard(label: String, value: String, modifier: Modifier) { Card(modifier) { Column(Modifier.padding(14.dp)) { Text(label, style = MaterialTheme.typography.labelMedium); Text(value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) } } }
    @Composable private fun PageScroll(content: @Composable ColumnScope.() -> Unit) { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content) }
    @Composable private fun itemsColumn(list: List<InstalledApp>, row: @Composable (InstalledApp) -> Unit) { list.take(80).forEach { row(it) } }
    @Composable private fun RowScope.navItem(icon: String, label: String, selected: Boolean, onClick: () -> Unit) { NavigationBarItem(selected, onClick, icon = { Text(icon) }, label = { Text(label, fontSize = 9.sp) }) }
    private fun fmt(v: Long) = Formatter.formatFileSize(this, v)
}
