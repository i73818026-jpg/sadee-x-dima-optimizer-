package com.sadee.dima.optimizer
object AppConfig {
    // Set these in your private fork/repository before building.
    const val SUPABASE_URL = "https://YOUR_PROJECT.supabase.co"
    const val SUPABASE_ANON_KEY = "YOUR_ANON_KEY"
    const val VALIDATE_FUNCTION = "$SUPABASE_URL/functions/v1/validate-key"
    const val CONFIG_FUNCTION = "$SUPABASE_URL/functions/v1/app-config"
}
