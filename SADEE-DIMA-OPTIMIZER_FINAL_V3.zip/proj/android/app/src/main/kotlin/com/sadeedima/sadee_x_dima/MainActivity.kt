package com.sadeedima.sadee_x_dima

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
