import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/key_service.dart';

class AdminHomeScreen extends StatefulWidget {
  const AdminHomeScreen({super.key});

  @override
  State<AdminHomeScreen> createState() => _AdminHomeScreenState();
}

class _AdminHomeScreenState extends State<AdminHomeScreen> {
  final KeyService _keyService = KeyService();
  int _selectedDuration = 1;
  List<Map<String, dynamic>> _keysList = [];
  bool _isLoading = false;

  final List<int> _durations = [1, 3, 5, 7, 14, 30, -1];

  @override
  void initState() {
    super.initState();
    _refreshKeys();
  }

  Future<void> _refreshKeys() async {
    if (!mounted) return;

    setState(() => _isLoading = true);

    try {
      final keys = await _keyService
          .fetchAllKeys()
          .timeout(const Duration(seconds: 10));

      if (!mounted) return;

      setState(() {
        _keysList = keys;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _keysList = [];
        _isLoading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("License keys load failed: $e"),
          backgroundColor: Colors.redAccent,
        ),
      );
    }
  }

  Future<void> _generateKey() async {
    try {
      final newKey = await _keyService.createLicenseKey(_selectedDuration);
      if (!mounted) return;

      await _refreshKeys();
      if (!mounted) return;

      await showDialog<void>(
        context: context,
        builder: (_) => AlertDialog(
          backgroundColor: const Color(0xFF1D1B3A),
          title: const Text(
            "Generated Key",
            style: TextStyle(color: Colors.cyanAccent),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SelectableText(
                newKey,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                _selectedDuration == -1
                    ? "Duration: Lifetime"
                    : "Duration: $_selectedDuration Days",
                style: const TextStyle(color: Colors.white70),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Clipboard.setData(ClipboardData(text: newKey));
                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Key Copied to Clipboard!")),
                );
              },
              child: const Text(
                "COPY KEY",
                style: TextStyle(color: Colors.cyanAccent),
              ),
            ),
          ],
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Key generation failed: $e"),
          backgroundColor: Colors.redAccent,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F0C20),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1D1B3A),
        title: const Text('Sadee Admin Control Panel', style: TextStyle(color: Colors.redAccent)),
        actions: [
          IconButton(onPressed: _refreshKeys, icon: const Icon(Icons.refresh))
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Generator Box
            Card(
              color: const Color(0xFF1D1B3A),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text("Generate New License Key",
                        style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        const Text("Select Duration: ", style: TextStyle(color: Colors.white70)),
                        const SizedBox(width: 10),
                        DropdownButton<int>(
                          dropdownColor: const Color(0xFF1D1B3A),
                          value: _selectedDuration,
                          style: const TextStyle(color: Colors.cyanAccent, fontWeight: FontWeight.bold),
                          items: _durations.map((d) {
                            return DropdownMenuItem<int>(
                              value: d,
                              child: Text(d == -1 ? "Lifetime (-1)" : "$d Days"),
                            );
                          }).toList(),
                          onChanged: (val) {
                            if (val != null) setState(() => _selectedDuration = val);
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.redAccent,
                        minimumSize: const Size(double.infinity, 45),
                      ),
                      icon: const Icon(Icons.key, color: Colors.white),
                      label: const Text("GENERATE KEY NOW", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                      onPressed: _generateKey,
                    )
                  ],
                ),
              ),
            ),

            const SizedBox(height: 20),
            const Text("All License Keys", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),

            Expanded(
              child: _isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : ListView.builder(
                      itemCount: _keysList.length,
                      itemBuilder: (context, index) {
                        var k = _keysList[index];
                        String status = k['status'] ?? 'UNUSED';
                        Color statusColor = status == 'ACTIVE'
                            ? Colors.green
                            : (status == 'PAUSED' ? Colors.amber : (status == 'EXPIRED' ? Colors.red : Colors.cyan));

                        return Card(
                          color: const Color(0xFF18152E),
                          child: ListTile(
                            title: Text(k['key_code'] ?? '',
                                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                            subtitle: Text(
                              "Duration: ${k['duration_days']}d | Status: $status\n"
                              "Device: ${k['device_id'] ?? 'Not Bound'}",
                              style: const TextStyle(color: Colors.white60, fontSize: 12),
                            ),
                            trailing: PopupMenuButton<String>(
                              icon: Icon(Icons.more_vert, color: statusColor),
                              onSelected: (action) async {
                                try {
                                  final keyCode = k['key_code'] as String;
                                  if (action == 'PAUSE') {
                                    await _keyService.updateKeyStatus(keyCode, 'PAUSED');
                                  } else if (action == 'UNPAUSE') {
                                    await _keyService.updateKeyStatus(keyCode, 'ACTIVE');
                                  } else if (action == 'EXPIRE') {
                                    await _keyService.updateKeyStatus(keyCode, 'EXPIRED');
                                  } else if (action == 'DELETE') {
                                    await _keyService.deleteKey(keyCode);
                                  }
                                  await _refreshKeys();
                                } catch (e) {
                                  if (!mounted) return;
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text("Action failed: $e"),
                                      backgroundColor: Colors.redAccent,
                                    ),
                                  );
                                }
                              },
                              itemBuilder: (_) => [
                                const PopupMenuItem(value: 'PAUSE', child: Text("Pause Key")),
                                const PopupMenuItem(value: 'UNPAUSE', child: Text("Unpause Key")),
                                const PopupMenuItem(value: 'EXPIRE', child: Text("Expire Key")),
                                const PopupMenuItem(value: 'DELETE', child: Text("Delete Key")),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            )
          ],
        ),
      ),
    );
  }
}
